#!/bin/sh

do_unnum () {
  local INF=$1
  local OTF=$2

iconv -f CP932 -t UTF-8 $INF | awk -v ORS='\r\n' '
{ soc = substr($0, 7); 
  print "      " soc;
} ' | iconv -f UTF-8 -t CP932 > $OTF 

}

for FILE in  soc.bk/*
do
  BASENAME=${FILE##*/}
  echo "$BASENAME"
  do_unnum soc.bk/$BASENAME soc/$BASENAME
done

